package com.supcon.patrol.entity;
public class Point {

    /**
     * 点code
     */
    private String pointCode;

    /**
     * 经度
     */
    private Double longitude;

    /**
     * 纬度
     */
    private Double dimensionality;

    public String getPointCode() {
        return pointCode;
    }

    public void setPointCode(String pointCode) {
        this.pointCode = pointCode;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getDimensionality() {
        return dimensionality;
    }

    public void setDimensionality(Double dimensionality) {
        this.dimensionality = dimensionality;
    }
}
