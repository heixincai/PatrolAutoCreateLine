package com.supcon.patrol.createline;

import com.supcon.patrol.entity.Point;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class FindTheWayService {

    /**
     * 地球半径，单位：米
     */
    private static final Integer EARTH_RADIUS = 6378137;

    /**
     * 寻找最短路径
     * @param pointList
     * @return
     */
    public List<Point> findShortestWay(List<Point> pointList) {
        final List<Point> result = new ArrayList<>();
        final List<List<Double>> distanceTable = buildDistanceTable(pointList);
        int start = findStart(distanceTable);

        show(distanceTable);

        result.add(pointList.get(start));

        for(int usedPoint = 1; usedPoint < pointList.size(); usedPoint++){
            int next = findNextShortest(distanceTable, start,pointList, result);
            result.add(pointList.get(next));
            start = next;
        }

        return result;
    }

    /**
     * 线路的起始点
     * @param distanceTable
     * @return
     */
    private Integer findStart(List<List<Double>> distanceTable) {
        double max = Double.MIN_VALUE;
        int start = -1;

        for (int i = 0; i < distanceTable.size(); i++) {
            List<Double> distanceList = distanceTable.get(i);

            for (int j = i + 1; j < distanceList.size(); j++) {
                double distance = distanceList.get(j);
                if(Objects.equals(-1D, distance)){
                    continue;
                }

                if (max <= distance) {
                    max = distance;
                    start = j;
                }
            }
        }

        return start;
    }

    /**
     * 寻找下一个最短路径点
     * @param distanceTable 距离矩阵
     * @param start 起始点
     * @param pointList 当前线路所有点
     * @param usedPointList 已经查找到的点
     * @return
     */
    private Integer findNextShortest(List<List<Double>> distanceTable, Integer start,List<Point> pointList, List<Point> usedPointList){
        double min = Double.MAX_VALUE;
        int next = -1;

        for(int i = 0; i < distanceTable.size(); i++){
            List<Double> distanceList = distanceTable.get(i);
            for(int j = 0; j < distanceList.size(); j++){
                if(!Objects.equals(start, j) || usedPointList.contains(pointList.get(i)) || Objects.equals(-1D, distanceList.get(j))){
                    continue;
                }

                double distance = distanceList.get(j);
                if(distance < min){
                    min = distance;
                    next = i;
                }
            }
        }

        return next;
    }

    /**
     * 显示距离矩阵
     * @param distanceTable
     */
    public void show(List<List<Double>> distanceTable) {
        for (int i = 0; i < distanceTable.size(); i++) {
            List<Double> distanceList = distanceTable.get(i);

            for (int j = 0; j < distanceList.size(); j++) {
                System.out.print(" " + distanceList.get(j));
            }

            System.out.println("\n");
        }
    }

    /**
     * 计算点列表的距离，并构成矩阵
     * @param pointList
     * @return
     */
    private List<List<Double>> buildDistanceTable(List<Point> pointList) {
        List<List<Double>> distanceTable = buildEmptyNestList(pointList.size());

        for (int i = 0; i < pointList.size(); i++) {
            for (int j = 0; j < pointList.size(); j++) {
                if (i == j) {
                    distanceTable.get(i).add(-1D);
                    continue;
                }

                distanceTable.get(i).add(calcDistance(pointList.get(i), pointList.get(j)));
            }
        }

        return distanceTable;
    }

    /**
     * 建造空嵌套列表
     * @param size
     * @return
     */
    private List<List<Double>> buildEmptyNestList(Integer size) {
        List<List<Double>> result = new ArrayList<>();

        for (int i = 0; i < size; i++) {
            result.add(new ArrayList<Double>());
        }

        return result;
    }

    /**
     * 根据两点的经纬度计算两点的距离
     * @param point1
     * @param point2
     * @return两个点之间的距离m
     */
    public Double calcDistance(Point point1, Point point2) {
        double radLat1 = rad(point1.getLongitude());
        double radLat2 = rad(point2.getLongitude());
        double differenceOfLat = radLat1 - radLat2;
        double differenceOfLng = rad(point1.getDimensionality()) - rad(point2.getDimensionality());

        return EARTH_RADIUS
                * 2
                * Math.asin(Math.sqrt(Math.pow(Math.sin(differenceOfLat / 2), 2)
                + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(differenceOfLng / 2), 2)));
    }

    private Double rad(double d) {
        return d * Math.PI / 180.0;
    }
}

