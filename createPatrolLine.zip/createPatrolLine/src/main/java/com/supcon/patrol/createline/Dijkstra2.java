package com.supcon.patrol.createline;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

//迪杰斯特拉算法求图中任意两个节点的最短路径
public class Dijkstra2 {
    private int MAX=Integer.MAX_VALUE;
    private int[][] map=new int[][]{
            {0,1,5,MAX,MAX,MAX,MAX,MAX,MAX},
            {1,0,3,7,5,MAX,MAX,MAX,MAX},
            {5,3,0,MAX,1,7,MAX,MAX,MAX},
            {MAX,7,MAX,0,2,MAX,3,MAX,MAX},
            {MAX,5,1,2,0,3,6,9,MAX},
            {MAX,MAX,7,MAX,3,0,MAX,5,MAX},
            {MAX,MAX,MAX,3,6,MAX,0,2,7},
            {MAX,MAX,MAX,MAX,9,5,2,0,4},
            {MAX,MAX,MAX,MAX,MAX,MAX,7,4,0}

    };
    public static void main(String[] args) throws InterruptedException{
        Dijkstra2 demo=new Dijkstra2();
        //demo.getResult(0);
        //System.out.println(demo.isTwoSame(demo.map));
        demo.getResult(1);
    }


    //获取计算结果，其中m要求的那个节点
    public void getResult(int m){
        int length=map.length;
        int[] result=new int[length];
        for(int i=0;i<result.length;i++){
            result[i]=map[m][i];
        }

        Set<Integer> set=new HashSet<Integer>();
        int min=Integer.MAX_VALUE;
        int index=-1;
        //int sum=0;
        set.add(m);
        for(int k=0;k<length;k++){
            min=Integer.MAX_VALUE;
            //找一维矩阵中的最小值，和下标，后面用这个小标来更新矩阵。
            for(int i=0;i<length;++i){
                if(!set.contains(i)){
                    if(result[i]<min){
                        min=result[i];
                        index=i;
                    }
                }
            }


            //更新一维矩阵
            if(index!=-1){
                set.add(index);
                for(int j=0;j<length;j++){
                    if(!set.contains(j) && map[index][j]!=MAX && (min+map[index][j])<result[j]){
                        result[j]=min+map[index][j];
                    }
                }
            }

        }
        //输出结果
        System.out.println(Arrays.toString(result));

    }


    //判断矩阵是否为对称矩阵，防止一不小心输错了数据。
    public boolean isTwoSame(int[][] data){
        for(int i=0;i<data.length;i++){
            for(int j=i+1;j<data[i].length;j++){
                if(data[i][j]!=data[j][i]){
                    //System.out.println(i+"-->"+j);
                    //System.out.println(data[i][j]+"-->"+data[j][i]);
                    return false;
                }
            }
        }
        return true;
    }
}


