package com.supcon.patrol.createline;

import com.supcon.patrol.entity.Point;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class PlanLinePoint {
    private ArrayList<Point> linePointList = new ArrayList<>();// 巡检点组合生成巡检线路
    private ArrayList<List<Point>> lineList = new ArrayList<>();// 巡检线路的集合

    public ArrayList<List<Point>> createLine(ArrayList<String> workShopList, HashMap<String, List<Point>> map, int pointNumber,int lineNumber){
        HashMap<String, List<Point>> workPointMap = map;
        ArrayList<String> workShop = workShopList;
        Boolean isOk = true;
        while(isOk){
            linePointList = generateLine(workShop,workPointMap,pointNumber,lineNumber);//获取一条巡检线路
            lineList.add(linePointList);
            linePointList = new ArrayList<Point>();
            if(lineList.size() == (lineNumber - 1)){//最后一条线路取出剩下所有的点
                linePointList = generateLastLine(workShop,workPointMap);
                lineList.add(linePointList);
            }
            if(lineList.size() == lineNumber){//生成的巡检线路数量满足要求的数量即可停止生成
                isOk = false;
            }
        }
        return lineList;
    }
    /**
     * 生成n-1条巡检线路
     * @param workShop
     * @param workPointMap
     * @param pointNumber
     * @param lineNumber
     * @return
     */
    public ArrayList<Point> generateLine(ArrayList<String> workShop, HashMap<String, List<Point>> workPointMap, int pointNumber, int lineNumber) {
        int workShopSize = workShop.size();// 车间数
        // 1.每个车间先随机选取一个巡检点
        for (int i = 0; i < workShopSize; i++) {
            String workShopCode = workShop.get(i);
            int pointCount = workPointMap.get(workShopCode).size();// 该车间仓对应的巡检点个数
            if(pointCount > 0){
                // 获取任一一个巡检点放入linePointList
                int index = new Random().nextInt(pointCount);// 随机生成0-pointCount的下标
                linePointList.add(workPointMap.get(workShopCode).get(index));
                workPointMap.get(workShopCode).remove(index);// 已经生成巡检线路的点移除
            }
            if (linePointList.size() == pointNumber) {// 2.如果每条线路中生成的巡检点个数满足平均巡检点个数要求，则停止遍历
                break;
            }
        }
        if (linePointList.size() < pointNumber) {// 3.如果每条线路中生成的巡检点个数不满足平均巡检点个数要求，则继续遍历
            generateLine(workShop,workPointMap,pointNumber,lineNumber);
        }
        return linePointList;
    }
    /**
     * 当生成最后一条线路时：将剩下的所有点作为最后一条线路
     * @param workShop
     * @param workPointMap
     * @return
     */
    public ArrayList<Point> generateLastLine(ArrayList<String> workShop,HashMap<String, List<Point>> workPointMap){
        int workShopSize = workShop.size();// 车间数
        for (int i = 0; i < workShopSize; i++) {
            String workShopCode = workShop.get(i);
            int pointCount = workPointMap.get(workShopCode).size();// 该车间仓对应的巡检点个数
            for(int j = 0 ; j < pointCount ; j ++){
                linePointList.add(workPointMap.get(workShopCode).get(j));
            }
        }
        return linePointList;
    }
}
