package com.supcon.patrol.test;

import com.supcon.patrol.createline.FindTheWayService;
import com.supcon.patrol.createline.PlanLinePoint;
import com.supcon.patrol.entity.Point;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FindTheWayServiceTest {

    private static final List<Point> testData = new ArrayList<>();

    private static final FindTheWayService findTheWayService = new FindTheWayService();

    static{
        for(int i = 0 ; i < 5 ; i ++){
            Point point = new Point();
            point.setPointCode("point_00"+i);
            point.setLongitude(new Random().nextDouble());
            point.setDimensionality(new Random().nextDouble());
            testData.add(point);
        }
        /*Point point1 = new Point();//北京
        point1.setPointCode("point_001");
        point1.setLongitude(39.26);
        point1.setDimensionality(115.25);
        testData.add(point1);
        Point point2 = new Point();//上海
        point2.setPointCode("point_002");
        point2.setLongitude(30.40);
        point2.setDimensionality(120.51);
        testData.add(point2);
        Point point3 = new Point();//杭州
        point3.setPointCode("point_003");
        point3.setLongitude(29.11);
        point3.setDimensionality(118.21);
        testData.add(point3);
        Point point4 = new Point();//合肥
        point4.setPointCode("point_004");
        point4.setLongitude(31.49);
        point4.setDimensionality(117.28);
        testData.add(point4);
        Point point5 = new Point();//南京
        point5.setPointCode("point_005");
        point5.setLongitude(31.14);
        point5.setDimensionality(118.22);
        testData.add(point5);*/
    }

    public static void test(){
        List<Point> shortLinePoint = findTheWayService.findShortestWay(testData);
        shortLinePoint.forEach(point -> System.out.print(" " + point.getPointCode()));
    }

    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        System.out.println("开始时间："+startTime);
        test();
        long endTime = System.currentTimeMillis();
        System.out.println();
        System.out.println("结束时间："+endTime);
        System.out.println("耗费时间："+(endTime - startTime)+"ms");
    }
}
