package com.supcon.patrol.test;

import com.supcon.patrol.createline.PlanLinePoint;
import com.supcon.patrol.entity.Point;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;


public class TestArrayList {

    public static void main(String[] args) {
        List<Point> list = new ArrayList<>();
        List<Point> list2 = new ArrayList<>();
        List<Point> list3 = new ArrayList<>();
        List<Point> list4 = new ArrayList<>();
        List<Point> list5 = new ArrayList<>();
        HashMap<String,List<Point>> map = new HashMap<String,List<Point>>();
        ArrayList arr ;
        for(int i = 0 ; i < 5 ; i ++){
            Point point = new Point();
            point.setPointCode("point_00"+i);
            point.setLongitude(new Random().nextDouble());
            point.setDimensionality(new Random().nextDouble());
            list.add(point);
        }
        map.put("work_001",list);
        for(int i = 5 ; i < 10 ; i ++){
            Point point = new Point();
            point.setPointCode("point_00"+i);
            point.setLongitude(new Random().nextDouble());
            point.setDimensionality(new Random().nextDouble());
            list2.add(point);
        }
        map.put("work_002",list2);
        for(int i = 10 ; i < 17 ; i ++){
            Point point = new Point();
            point.setPointCode("point_00"+i);
            point.setLongitude(new Random().nextDouble());
            point.setDimensionality(new Random().nextDouble());
            list3.add(point);
        }
        map.put("work_003",list3);
        for(int i = 17 ; i < 20 ; i ++){
            Point point = new Point();
            point.setPointCode("point_00"+i);
            point.setLongitude(new Random().nextDouble());
            point.setDimensionality(new Random().nextDouble());
            list4.add(point);
        }
        map.put("work_004",list4);
        for(int i = 20 ; i < 24 ; i ++){
            Point point = new Point();
            point.setPointCode("point_00"+i);
            point.setLongitude(new Random().nextDouble());
            point.setDimensionality(new Random().nextDouble());
            list5.add(point);
        }
        map.put("work_005",list5);
        ArrayList<String> workShopList = new ArrayList<String>();
        workShopList.add("work_001");
        workShopList.add("work_002");
        workShopList.add("work_003");
        workShopList.add("work_004");
        workShopList.add("work_005");
        int pointNum = 24;
        int linePointCount = pointNum/5;
        long startTime = System.currentTimeMillis();
        System.out.println("开始时间："+startTime);
        new PlanLinePoint().createLine(workShopList, map,linePointCount,5);
        long endTime = System.currentTimeMillis();
        System.out.println("结束时间："+endTime);
        System.out.println("耗费时间："+(endTime - startTime)+"ms");
    }

}
