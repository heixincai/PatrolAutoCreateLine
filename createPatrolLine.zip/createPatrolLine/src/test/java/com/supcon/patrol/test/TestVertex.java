package com.supcon.patrol.test;

import com.supcon.patrol.createline.Graph;
import com.supcon.patrol.createline.Vertex;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class TestVertex {
    @Test
    public void testVertex(){
        List<Vertex> vertex = new ArrayList<Vertex>();
        Vertex a = new Vertex("A", 0);
        Vertex b = new Vertex("B");
        Vertex c = new Vertex("C");
        Vertex d = new Vertex("D");
        Vertex e = new Vertex("E");
        Vertex f = new Vertex("F");
        vertex.add(a);
        vertex.add(b);
        vertex.add(c);
        vertex.add(d);
        vertex.add(e);
        vertex.add(f);
        int[][] edges = {
                {Integer.MAX_VALUE,6,3,Integer.MAX_VALUE,Integer.MAX_VALUE,Integer.MAX_VALUE},
                {6,Integer.MAX_VALUE,2,5,Integer.MAX_VALUE,Integer.MAX_VALUE},
                {3,2,Integer.MAX_VALUE,3,4,Integer.MAX_VALUE},
                {Integer.MAX_VALUE,5,3,Integer.MAX_VALUE,5,3},
                {Integer.MAX_VALUE,Integer.MAX_VALUE,4,5,Integer.MAX_VALUE,5},
                {Integer.MAX_VALUE,Integer.MAX_VALUE,Integer.MAX_VALUE,3,5,Integer.MAX_VALUE}

        };
        Graph graph = new Graph(vertex, edges);
        graph.printGraph();
        graph.search();
    }
}
